"use client"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type Difficulty = "easy" | "medium" | "hard"

interface DifficultySelectorProps {
  difficulty: Difficulty
  onChange: (difficulty: Difficulty) => void
  disabled?: boolean
}

export default function DifficultySelector({ difficulty, onChange, disabled = false }: DifficultySelectorProps) {
  return (
    <div className="flex flex-wrap justify-center gap-2 mb-6">
      <Button
        variant={difficulty === "easy" ? "default" : "outline"}
        onClick={() => onChange("easy")}
        disabled={disabled}
        className={cn("px-4 py-2", difficulty === "easy" && "bg-green-600 hover:bg-green-700")}
      >
        Easy
      </Button>
      <Button
        variant={difficulty === "medium" ? "default" : "outline"}
        onClick={() => onChange("medium")}
        disabled={disabled}
        className={cn("px-4 py-2", difficulty === "medium" && "bg-yellow-600 hover:bg-yellow-700")}
      >
        Medium
      </Button>
      <Button
        variant={difficulty === "hard" ? "default" : "outline"}
        onClick={() => onChange("hard")}
        disabled={disabled}
        className={cn("px-4 py-2", difficulty === "hard" && "bg-red-600 hover:bg-red-700")}
      >
        Hard
      </Button>
    </div>
  )
}
