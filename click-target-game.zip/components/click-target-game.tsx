"use client"

import { useState, useEffect, useRef } from "react"
import { Target } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import DifficultySelector from "./difficulty-selector"
import GameOverModal from "./game-over-modal"

// Difficulty settings
const DIFFICULTY_SETTINGS = {
  easy: { targetSize: 80, moveInterval: 1500, timeLimit: 30 },
  medium: { targetSize: 60, moveInterval: 1000, timeLimit: 25 },
  hard: { targetSize: 40, moveInterval: 700, timeLimit: 20 },
}

type Difficulty = "easy" | "medium" | "hard"

export default function ClickTargetGame() {
  const [gameActive, setGameActive] = useState(false)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(30)
  const [targetPosition, setTargetPosition] = useState({ x: 50, y: 50 })
  const [difficulty, setDifficulty] = useState<Difficulty>("medium")
  const [showGameOver, setShowGameOver] = useState(false)
  const [autoMoveEnabled, setAutoMoveEnabled] = useState(false)

  const gameAreaRef = useRef<HTMLDivElement>(null)
  const timerInterval = useRef<NodeJS.Timeout | null>(null)
  const moveInterval = useRef<NodeJS.Timeout | null>(null)

  // Get current difficulty settings
  const currentSettings = DIFFICULTY_SETTINGS[difficulty]

  // Start or restart the game
  const startGame = () => {
    setGameActive(true)
    setScore(0)
    setTimeLeft(currentSettings.timeLimit)
    setShowGameOver(false)
    moveTarget()

    // Start auto-movement based on difficulty
    if (autoMoveEnabled) {
      startAutoMove()
    }
  }

  // End the game
  const endGame = () => {
    setGameActive(false)
    setShowGameOver(true)

    if (timerInterval.current) {
      clearInterval(timerInterval.current)
      timerInterval.current = null
    }

    if (moveInterval.current) {
      clearInterval(moveInterval.current)
      moveInterval.current = null
    }
  }

  // Start auto-movement of target
  const startAutoMove = () => {
    if (moveInterval.current) {
      clearInterval(moveInterval.current)
    }

    moveInterval.current = setInterval(() => {
      moveTarget()
    }, currentSettings.moveInterval)
  }

  // Move the target to a random position
  const moveTarget = () => {
    if (gameAreaRef.current) {
      const gameArea = gameAreaRef.current
      const maxX = gameArea.clientWidth - currentSettings.targetSize
      const maxY = gameArea.clientHeight - currentSettings.targetSize

      // Ensure target stays within bounds
      const newX = Math.max(0, Math.min(Math.floor(Math.random() * maxX), maxX))
      const newY = Math.max(0, Math.min(Math.floor(Math.random() * maxY), maxY))

      setTargetPosition({ x: newX, y: newY })
    }
  }

  // Handle target click
  const handleTargetClick = () => {
    if (gameActive) {
      setScore((prevScore) => prevScore + 1)
      moveTarget()
    }
  }

  // Handle difficulty change
  const handleDifficultyChange = (newDifficulty: Difficulty) => {
    if (!gameActive) {
      setDifficulty(newDifficulty)
      setTimeLeft(DIFFICULTY_SETTINGS[newDifficulty].timeLimit)
    }
  }

  // Toggle auto-move feature
  const toggleAutoMove = () => {
    setAutoMoveEnabled(!autoMoveEnabled)
  }

  // Timer effect
  useEffect(() => {
    if (gameActive) {
      timerInterval.current = setInterval(() => {
        setTimeLeft((prevTime) => {
          if (prevTime <= 1) {
            endGame()
            return 0
          }
          return prevTime - 1
        })
      }, 1000)
    }

    return () => {
      if (timerInterval.current) {
        clearInterval(timerInterval.current)
      }
    }
  }, [gameActive])

  // Handle auto-move when difficulty changes
  useEffect(() => {
    if (gameActive && autoMoveEnabled) {
      startAutoMove()
    }

    return () => {
      if (moveInterval.current) {
        clearInterval(moveInterval.current)
      }
    }
  }, [difficulty, gameActive, autoMoveEnabled])

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      if (gameActive) {
        moveTarget()
      }
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [gameActive])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerInterval.current) clearInterval(timerInterval.current)
      if (moveInterval.current) clearInterval(moveInterval.current)
    }
  }, [])

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col items-center">
      {/* Game Title */}
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-4">Click the Target</h1>

      {/* Difficulty Selector */}
      <DifficultySelector difficulty={difficulty} onChange={handleDifficultyChange} disabled={gameActive} />

      {/* Auto-move toggle */}
      <div className="mb-4 flex items-center">
        <label className="flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={autoMoveEnabled}
            onChange={toggleAutoMove}
            disabled={gameActive}
            className="sr-only peer"
          />
          <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          <span className="ml-3 text-sm font-medium">Auto-move target</span>
        </label>
      </div>

      {/* Score and Timer */}
      <div className="w-full flex justify-between mb-4 px-4">
        <div className="text-xl font-semibold">Score: {score}</div>
        <div className={cn("text-xl font-semibold", timeLeft <= 10 && gameActive ? "text-red-500" : "")}>
          Time: {timeLeft}s
        </div>
      </div>

      {/* Game Area */}
      <div
        ref={gameAreaRef}
        className="relative w-full aspect-video bg-slate-100 rounded-lg shadow-inner mb-6 overflow-hidden"
      >
        {gameActive && (
          <div
            className="absolute cursor-pointer transition-transform duration-100 hover:scale-105"
            style={{
              left: `${targetPosition.x}px`,
              top: `${targetPosition.y}px`,
              width: `${currentSettings.targetSize}px`,
              height: `${currentSettings.targetSize}px`,
              transition: `left ${difficulty === "hard" ? "0.2s" : "0.3s"} ease-out, top ${difficulty === "hard" ? "0.2s" : "0.3s"} ease-out`,
            }}
            onClick={handleTargetClick}
          >
            <div className="w-full h-full rounded-full bg-red-500 flex items-center justify-center animate-pulse shadow-md">
              <Target
                className="text-white"
                style={{
                  width: `${currentSettings.targetSize / 2}px`,
                  height: `${currentSettings.targetSize / 2}px`,
                }}
              />
            </div>
          </div>
        )}

        {!gameActive && !showGameOver && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/10">
            <div className="text-center p-6 rounded-lg">
              <p className="text-2xl font-bold mb-4">Click Start to begin!</p>
              <p className="text-lg">
                {difficulty === "easy"
                  ? "Easy: Large target, slow movement"
                  : difficulty === "medium"
                    ? "Medium: Medium target, faster movement"
                    : "Hard: Small target, rapid movement"}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Start/Restart Button */}
      <Button size="lg" onClick={gameActive ? endGame : startGame} className="px-8 py-6 text-lg">
        {gameActive ? "End Game" : score > 0 ? "Play Again" : "Start Game"}
      </Button>

      {/* Game Over Modal */}
      <GameOverModal
        isOpen={showGameOver}
        onClose={() => setShowGameOver(false)}
        score={score}
        difficulty={difficulty}
      />
    </div>
  )
}
