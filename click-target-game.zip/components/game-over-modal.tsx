"use client"

import { Button } from "@/components/ui/button"

interface GameOverModalProps {
  isOpen: boolean
  onClose: () => void
  score: number
  difficulty: "easy" | "medium" | "hard"
}

export default function GameOverModal({ isOpen, onClose, score, difficulty }: GameOverModalProps) {
  if (!isOpen) return null

  // Get message based on score and difficulty
  const getMessage = () => {
    const thresholds = {
      easy: { low: 5, medium: 10, high: 15 },
      medium: { low: 8, medium: 15, high: 20 },
      hard: { low: 10, medium: 18, high: 25 },
    }

    const current = thresholds[difficulty]

    if (score >= current.high) return "Amazing job! You're a pro!"
    if (score >= current.medium) return "Great job! You've got skills!"
    if (score >= current.low) return "Good effort! Keep practicing!"
    return "Nice try! You'll get better with practice."
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full">
        <h2 className="text-2xl font-bold mb-4 text-center">Game Over!</h2>

        <div className="text-center mb-6">
          <p className="text-4xl font-bold text-blue-600 mb-2">{score}</p>
          <p className="text-gray-600">Your final score on {difficulty} difficulty</p>
          <p className="mt-4 text-lg">{getMessage()}</p>
        </div>

        <div className="flex justify-center">
          <Button onClick={onClose} className="px-6 py-2">
            Close
          </Button>
        </div>
      </div>
    </div>
  )
}
